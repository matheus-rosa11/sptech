package sptech.school.login01221141matheus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Login01221141MatheusApplication {

	public static void main(String[] args) {
		SpringApplication.run(Login01221141MatheusApplication.class, args);
	}

}
