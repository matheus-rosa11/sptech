package sptech.school.login01221141matheus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Login01221141MatheusApplicationTests {

	@Test
	void contextLoads() {
	}

}
