package sptech.school.introducaojpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntroducaoJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
