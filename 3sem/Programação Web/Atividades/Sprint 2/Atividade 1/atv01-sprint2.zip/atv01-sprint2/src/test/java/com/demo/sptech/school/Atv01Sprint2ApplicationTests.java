package com.demo.sptech.school;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Atv01Sprint2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
