package com.demo.sptech.school;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Atv01Sprint2Application {

	public static void main(String[] args) {
		SpringApplication.run(Atv01Sprint2Application.class, args);
	}

}
