package org.example;

public class Funcoes {
    public String escreverLinha() {
        return "===============================";
    }

    public void escreverLinhaVoid() {
        System.out.println("===============================");
    }
}
