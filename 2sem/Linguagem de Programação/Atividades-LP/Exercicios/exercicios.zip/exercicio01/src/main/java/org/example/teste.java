package org.example;

public class teste {
    public static void main(String[] args) {
        for(Integer i = 0; i <= 1000000000; i++){
            System.out.println(i);
        }
    }
}
